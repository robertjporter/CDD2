Theme Name: _tk
Theme URI: http://themekraft.com/store/_tk-free-wordpress-starter-theme-based-on-twitter-bootstrap/
Author: ThemeKraft
Author URI: http://themekraft.com/
Description: Hi, I am the ultra minimal starter theme _tk, ready for your next awesome WordPress project! I am the most seamless and minimalistic integration of Twitter Bootstrap Framework into the _s starter theme from Automattic, the guys behind WordPress. You can find me on GitHub. Fork me! I'm waiting for you ;)
Version: 1.1.10
License: GNU General Public License v3.0 /
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Tags: gray, light, two-columns, right-sidebar, responsive-layout, custom-background, custom-colors, custom-header, custom-menu, featured-images, flexible-header, sticky-post,  theme-options, threaded-comments, translation-ready

*************************************************************

This theme, like WordPress, is licensed under the GPL.
Use it to make something cool, have fun, and share what you've learned with others.

This theme is the most seamless and minimalistic integration of Twitter Bootstrap Framework into
the _s starter theme from Automattic, the guys behind WordPress.

_s (or Underscores) http://underscores.me/, (C) 2012-2013 Automattic, Inc. Twitter Bootstrap

*************************************************************

Credits:

1. Bootstrap

 * Bootstrap v3.3.6 (http://getbootstrap.com)
 * Copyright 2011-2015 Twitter, Inc.
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)

 * Generated using the Bootstrap Customizer (http://getbootstrap.com/customize/?id=f58353a31151a8c05d7c)
 * Config saved to config.json and https://gist.github.com/f58353a31151a8c05d7c

2. wp_bootstrap_navwalker

* Class Name: wp_bootstrap_navwalker
* GitHub URI: https://github.com/twittem/wp-bootstrap-navwalker

3. Glyphicons

 * http://getbootstrap.com/components/

*************************************************************

The _tk Project on Github - https://github.com/Themekraft/_tk/

*************************************************************


Thanks for using _tk Theme.
We hope you enjoy it!

*************************************************************
